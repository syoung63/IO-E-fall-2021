// Iteration of skeleton code example with a head outline added
// Based on code example from https://editor.p5js.org/ml5/sketches/PoseNet_webcam

let video;
let poseNet;
let poses = [];
let leftEarX = 0;
let leftEarY = 0;
let rightEarX = 0;
let rightEarY = 0;
let d;

let ready = false;

function setup(){

    createCanvas(windowWidth, windowHeight);
    video = createCapture(VIDEO);
    video.hide();
    video.size(windowWidth, windowHeight);

    poseNet = ml5.poseNet(video, {
        flipHorizontal: true //flips interaction
    }, modelLoaded);
    
    //Code from PoseNet webcam example by ml5
    // This sets up an event that fills the global variable "poses"
    // with an array every time new poses are detected
    poseNet.on('pose', function(results) {
        poses = results;
    });

}

function modelLoaded(){
    console.log("model ready");
    ready = true;
};


function draw(){
    
    //flips video to match interaction
    push();
    translate(windowWidth, 0);
    scale(-1.0, 1.0);
    image(video, 0, 0, windowWidth, windowHeight);
    scale(1.0, 1.0);
    pop();

    //Sets video to black
    filter(THRESHOLD, 1);

if(ready){

    //Find midpoints between ears
    let midX = ((rightEarX - leftEarX) / 2) + leftEarX;
    let midY = ((rightEarY - leftEarY) / 2) + leftEarY;

    //draw a circle with a center between the ears and a width of the distance between the ears
    stroke(255, 0, 255);
    fill(0);
    ellipse(midX, midY, d, d);

    //Call function to draw ellipses and lines on and between keypoints
    drawKeypoints();
    drawSkeleton();
}    
}

//Code from PoseNet webcam example by ml5

// A function to draw ellipses over the detected keypoints
function drawKeypoints()  {
    // Loop through all the poses detected
    for (let i = 0; i < poses.length; i++) {
      // For each pose detected, loop through all the keypoints
      let pose = poses[i].pose;

      d = int(dist(poses[0].pose.keypoints[3].position.x, poses[0].pose.keypoints[3].position.y, poses[0].pose.keypoints[4].position.x, poses[0].pose.keypoints[4].position.y));

      leftEarX = poses[0].pose.keypoints[3].position.x;
      leftEarY = poses[0].pose.keypoints[3].position.y;
      rightEarX = poses[0].pose.keypoints[4].position.x;
      rightEarY = poses[0].pose.keypoints[4].position.y;

      for (let j = 0; j < pose.keypoints.length; j++) {
        // A keypoint is an object describing a body part (like rightArm or leftShoulder)
        let keypoint = pose.keypoints[j];
        // Only draw an ellipse is the pose probability is bigger than 0.2
        if (keypoint.score > 0.2) {
          fill(0, 255, 255);
          noStroke();
          ellipse(keypoint.position.x, keypoint.position.y, 30, 30);
        }
      }
    }
  }

  // A function to draw the skeletons
function drawSkeleton() {
    // Loop through all the skeletons detected
    for (let i = 0; i < poses.length; i++) {
      let skeleton = poses[i].skeleton;
      // For every skeleton, loop through all body connections
      for (let j = 0; j < skeleton.length; j++) {
        let partA = skeleton[j][0];
        let partB = skeleton[j][1];
        strokeWeight(10);
        stroke(255, 0, 255);
        line(partA.position.x, partA.position.y, partB.position.x, partB.position.y);
      }
    }
  }
  





