// This sketch allows the user to change video and play sounds with voice control
// Combines PoseNet, p5.sound, and p5.speech libraries  
// Circle grow and shrink code adapted from https://editor.p5js.org/amcc/sketches/3ZLqytY_4
// Audio icon from flaticon.com https://www.flaticon.com/premium-icon/microphone_2989873?term=microphone&page=1&position=6&page=1&position=6&related_id=2989873&origin=search


let myRec = new p5.SpeechRec(); // new P5.SpeechRec object
let video;
let poseNet;
let ready = false;
let nX, nY;
let color = 'rgba(0,255,0, 0.25)';
let sound;
let img;
let invert = false;

let d = 50;
let growAmount = .5;
let grow = true;

//loads sound and image
function preload(){
    sound = loadSound('assets/sound_1.mp3');
    img = loadImage('assets/microphone.png');
}

function setup(){

	createCanvas(windowWidth, windowHeight);

	video = createCapture(VIDEO);
    video.hide();
    video.size(windowWidth, windowHeight);

	poseNet = ml5.poseNet(video, {
        flipHorizontal: true //flips interaction
    }, modelLoaded);
    poseNet.on('pose', gotPoses)

	let continuous = true;
	let interim = false;

    //Cause speech recognition engine to return results continuously
	myRec.start(continuous, interim);
}

function modelLoaded(){
    console.log("model ready");
};


function gotPoses(poses){
    console.log(poses);
    if( poses.length >0 ){
        //values hold nose x and y position
        nX = poses[0].pose.keypoints[0].position.x;
        nY = poses[0].pose.keypoints[0].position.y;
    } 
    
} 

function draw(){
    //Causes circle to grow and shrink indicating audio is ready to recieve input
    //Code adapted from https://editor.p5js.org/amcc/sketches/3ZLqytY_4
    if (d > 70) {
        grow = false
      }
      if (d < 50 && d > 0) {
        grow = true
      }
      
      if (grow == true) {
        d += growAmount
      } else {
        d -= growAmount
      }

//Once user has said "start"
if(ready==true){

    //flips video to match interactions
	push();
    translate(windowWidth, 0);
    scale(-1.0, 1.0);
    imageMode(CORNER);
    image(video, 0, 0, windowWidth, windowHeight);
    scale(1.0, 1.0);
    pop();

    //Runs filter over video when user says "play" and switches command
    if(invert==true && sound.isPlaying() == true){
        filter(INVERT);

        growAmount = 1;

        textSize(22);
        fill(255, 200);
        noStroke();
        textAlign(CENTER);
        text('"stop"', windowWidth/2, 500);
    }else{
        textSize(22);
        fill(255, 200);
        noStroke();
        textAlign(CENTER);
        text('"play"', windowWidth/2, 500);
    }

    //circle which grows and shrinks to indicate audio is ready to receive input
    fill(255, 100);
    noStroke();
    ellipse(nX,nY+300,d);

     //audio icon & background based on nose position
    fill(0, 150, 150);
    stroke(0, 150, 150);
    ellipse(nX,nY+300,50,50);

    imageMode(CENTER);
    image(img, nX, nY+300, 35, 35);

} 

//Initial opening screen runs if there is no result value yet
if(myRec.resultValue==undefined){
    background(0);

    //Start command
    textSize(22);
    fill(255, 200);
    noStroke();
    textAlign(CENTER);
    text('say "start"', windowWidth/2, 300); 

    //circle which grows and shrinks to indicate audio is ready to receive input
    fill(255, 100);
    noStroke();
    ellipse(windowWidth/2,500,d);

    //audio icon & background fixed until user says "start"
    fill(0, 150, 150);
    stroke(0, 150, 150);
    ellipse(windowWidth/2,500,50,50);

    imageMode(CORNER);
    image(img, windowWidth/2-17.5, 483, 35, 35);
}

myRec.onResult = showResult;

}

function showResult(){
	console.log(myRec.resultString);

    //Triggers graphics in the draw function based off different words
	if(myRec.resultString=="start" || myRec.resultString=="Start" ) {
        //Starts video and graphics in the draw function
		ready = true;
	}
    if(myRec.resultString=="stop" || myRec.resultString=="Stop" ){
		ready = false;
        background(0);
        sound.stop();
	}
    if(myRec.resultString=="play" || myRec.resultString=="Play" ){
		ready = true;
        invert = true;

        //Continues to play sound if sound is already playing and starts it if it hasn't started playing already 
        if(sound.isPlaying() == true){
            sound.playMode('sustain');
        }else{
            sound.play();
        }
	}
}