// This sketch changes the appearance of the screen and plays sound based on the position of the user's wrist

let sound;
let video;
let poseNet;
let wX, wY;
let color = 'rgba(0,255,0, 0.25)';

let ready = false;

function preload(){
    sound = loadSound('assets/sound_1.mp3');
}

function setup(){

    createCanvas(windowWidth, windowHeight);
    video = createCapture(VIDEO);
    video.hide();
    video.size(windowWidth, windowHeight);

    poseNet = ml5.poseNet(video, {
        flipHorizontal: true //flips interaction
    }, modelLoaded);
    poseNet.on('pose', gotPoses)

}

function modelLoaded(){
    console.log("model ready");
    ready = true;
};

function gotPoses(poses){
    console.log(poses);
    if( poses.length >0 ){
        //values hold left wrist x and y position
        wX = poses[0].pose.keypoints[9].position.x;
        wY = poses[0].pose.keypoints[9].position.y;
    } 
    
} 

function draw(){
    
    //flips video to match interaction
    push();
    translate(windowWidth, 0);
    scale(-1.0, 1.0);
    image(video, 0, 0, windowWidth, windowHeight);
    scale(1.0, 1.0);
    pop();

if(ready){

    fill(color)
    rect(windowWidth / 2, 0, windowWidth /2, windowHeight);

    fill(0,255,0);
    noStroke();
    ellipse(wX,wY,100,100);

    // will change video appearance and play sound if left wrist is on the right side of the screen
    if(wX > 500){
        //if sound is already playing continue playing otherwise start playing sound
        if(sound.isPlaying() == true){
            sound.playMode('sustain');
        }else{
            sound.play();
        }
        //apply filter to video
        filter(INVERT);
        color = 'rgba(0,255,0, 0.25)'
    } else{
        sound.stop();
        color = 'rgba(0,255,0, 0.25)'
    }
}    
}





