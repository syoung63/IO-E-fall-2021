// this is a very simple sketch that demonstrates how to place a video cam image into a canvas 

let video;
let pose;
let noseX = 0;
let noseY = 0;
let ready = false;

function setup(){
createCanvas(windowWidth, windowHeight);
video = createCapture(VIDEO);
video.hide();
video.size(windowWidth, windowHeight);
poseNet = ml5.poseNet(video, modelLoaded);
poseNet.on('pose', gotPoses)  

}

function modelLoaded(){
    console.log("model ready");
    ready = true;
};

function gotPoses(poses){
    console.log(poses);
    if( poses.length >0 ){
        pose = poses[0].pose;
    } 
    
} 

function draw(){
image(video, 0, 0, width, height);
if(pose){
    fill(255,0,0);
    ellipse(pose.nose.x, pose.nose.y, 40);
}  
    
}