// This sketch finds the midpoint between two shoulder points to display a bowtie on a person
// Based on shades example from Interactive Media course

let video;
let poseNet;
let bowtie;
let shoulderL, shoulderR;
let ang, d, scl;
let ready = false;

// loads image
function preload(){
    bowtie = loadImage("images/bow_tie.png");
}

function setup(){
    createCanvas(windowWidth, windowHeight);
    video = createCapture(VIDEO);
    video.hide();
    video.size(windowWidth, windowHeight);

    poseNet = ml5.poseNet(video, {
        flipHorizontal: true //flips interaction
    }, modelLoaded);
    poseNet.on('pose', gotPoses)

    shoulderL = createVector(0, 0);
    shoulderR = createVector(0, 0);
}

function modelLoaded(){
    console.log("model ready");
    ready = true;
};

function gotPoses(poses){
    console.log(poses);
    if( poses.length >0 ){
         //work out angle between eyes
        ang = atan2(poses[0].pose.keypoints[6].position.y - poses[0].pose.keypoints[5].position.y, poses[0].pose.keypoints[6].position.x - poses[0].pose.keypoints[5].position.x);
        //distance between eyes so can work out scale
        d = int(dist(poses[0].pose.keypoints[5].position.x, poses[0].pose.keypoints[5].position.y, poses[0].pose.keypoints[6].position.x, poses[0].pose.keypoints[6].position.y));
        scl = map(d, 0, 290, 0, 0.2);

        shoulderL.x = poses[0].pose.keypoints[5].position.x;
        shoulderL.y = poses[0].pose.keypoints[5].position.y;
        shoulderR.x = poses[0].pose.keypoints[6].position.x;
        shoulderR.y = poses[0].pose.keypoints[6].position.y;
    } 
    
} 

function draw(){
    //flips video to match interaction
    push();
    translate(windowWidth, 0);
    scale(-1.0, 1.0);
    image(video, 0, 0, windowWidth, windowHeight);
    scale(1.0, 1.0);
    pop();

if(ready){

    //find the mid point between the shoulders
    let midX = ((shoulderR.x - shoulderL.x) / 2) + shoulderL.x;
    let midY = ((shoulderR.y - shoulderL.y) / 2) + shoulderL.y;

    push();
    //position between shoulders
    translate(midX, midY);
    //rotate based on angle between shoulders
    rotate(ang + PI);
    //scale to fit
    scale(scl);
    //place image
    image(bowtie, 0 - bowtie.width / 2, 0 - bowtie.height / 2);
    pop();
}    
    
}




