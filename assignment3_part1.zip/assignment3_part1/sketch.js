// This sketch allows user to input text to be spoken and change the voice of the speaker
// Adapted from speech box example from https://idmnyu.github.io/p5.js-speech/ 
// Also uses code from Daniel Shiffman's text-to-speech tutorial https://thecodingtrain.com/learning/programming-with-text/10.3-text-to-speech.html

let speech = new p5.Speech(); // new P5.Speech object

let input;
let button;
let voiceButton;
let img;

function preload(){
	img = loadImage('assets/voice_icon.png');
}

function setup(){
	createCanvas(windowWidth, windowHeight);
	background(51, 153, 255);

	// input field to enter dialog
	input = createInput("hello there");
	input.size(400, 40);
	input.position(windowWidth/2 - 200, windowHeight/2-50);
	
	// button to initiate speech
	button = createButton('Speak');
	button.position(windowWidth/2 + 205, windowHeight/2-50);
	button.style('background-color', color(255, 102, 0));
	button.style('border', 0);
	button.style('color', color(255));
	button.size(80, 40);
	button.mousePressed(doSpeak);

	//button to change voice of speaker
	voiceButton = createImg('assets/voice_icon.png');
	voiceButton.position(windowWidth/2 + 297, windowHeight/2-43);
	voiceButton.style('background-color', color(255, 102, 0));
	voiceButton.style('border', 0);
	voiceButton.size(25, 25);
	voiceButton.mousePressed(voiceChange);

	//bakcground for voice button
	noStroke();
	fill(255, 102, 0);
	rect(windowWidth/2 + 290, windowHeight/2-50, 40, 40);

	// speaks the value inputted as soon as page is loaded
	speech.speak(input.value());

}

//function that speaks inputted value when called
function doSpeak(){
	speech.speak(input.value());
}

//function allows user to change to a random voice
function voiceChange(){
	let voices = speech.voices;
	let voice = random(voices);
	speech.setVoice(voice.name);
	speech.speak(input.value());
}

