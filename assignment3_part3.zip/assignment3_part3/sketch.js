// This sketch changes the color of the background to a color of the rainbow based off what the user says
// Adapted from simple recognition example from https://idmnyu.github.io/p5.js-speech/

let myRec = new p5.SpeechRec(); // new P5.SpeechRec object

function setup(){
	createCanvas(windowWidth, windowHeight);
	background(255, 255, 255);
	fill(0, 0, 0, 255);
	
	// command
	textSize(32);
	textAlign(CENTER);
	text("say a color", width/2, height/2);

	let continuous = true;
	let interim = false;

	myRec.onResult = showResult;
	//Causes speech recognition engine to return results continuously
	myRec.start(continuous, interim);
}


function showResult(){
	console.log(myRec.resultString);

	//Conditonal statement displays background color based on which color is recognized
	if(myRec.resultString=="red") {
		background(255, 89, 89);
		fill(196, 69, 69);
		text(myRec.resultString, width/2, height/2);
	}else if(myRec.resultString=="orange" || myRec.resultString=="Orange") {
		background(255, 159, 25);
		fill(237, 140, 5);
		text(myRec.resultString, width/2, height/2);
	}else if(myRec.resultString=="yellow") {
		background(255, 239, 97);
		fill(237, 218, 43);
		text(myRec.resultString, width/2, height/2);
	}else if(myRec.resultString=="green") {
		background(122, 255, 145);
		fill(84, 179, 100);
		text(myRec.resultString, width/2, height/2);
	}else if(myRec.resultString=="blue"){
		background(112, 184, 255);
		fill(62, 132, 201);
		text(myRec.resultString, width/2, height/2);
	}else if(myRec.resultString=="purple"){
		background(197, 71, 255);
		fill(160, 43, 214);
		text(myRec.resultString, width/2, height/2);
	}else if(myRec.resultString=="pink"){
		background(255, 156, 218);
		fill(232, 104, 185);
		text(myRec.resultString, width/2, height/2);
	}else if(myRec.resultValue==true){
		//If no colors are recognized it displays message asking user to try again
		background(255, 255, 255);
		
		textSize(32);
		textAlign(CENTER);
		fill(0);
		text("Sorry I don't know that color!", width/2, height/2);

		textSize(32);
		textAlign(CENTER);
		fill(0);
		text("Try again", width/2, height/2 *1.1);
	}
}