// This sketch draws a text bubble based on what the user says
// Adapted from simple recognition example from https://idmnyu.github.io/p5.js-speech/

let speechRec = new p5.SpeechRec(); // new P5.SpeechRec object
let p;
let pos;
let bbox;
let font;

function preload(){
	font = loadFont('./assets/poppins_medium.otf');
}

function setup(){
	createCanvas(windowWidth, windowHeight);
	background(51, 153, 255);
	
	speechRec.onResult = gotSpeech;

	//Causes speech recognition engine to return results continuously
	let continuous = true;
	let interim = false;
	speechRec.start(continuous, interim);

	//Initial Command
	textSize(32);
	fill(255);
	text('say something', windowWidth/2-100, windowHeight/2-100);
}

function gotSpeech(){
	//Runs if a speech value is recognized
	if(speechRec.resultValue){

		//Bounding box will change size of text bubble depending on the length of the string
		bbox = font.textBounds(speechRec.resultString, 100, 100, 32);
		console.log(bbox.w);

		//Detects size of bounding box to determine graphics and text positioning
		if(bbox.w > 2350){  //settings for longer paragraphs
			background(51, 153, 255);
			console.log("yes");

			noStroke();
			fill(255);
			triangle(bbox.x+45, bbox.y+10, 200, 0, 260, bbox.y+10);

			//Draws text bubble background based on the positioning of bounding box
			noStroke();
			fill(255);
			rect(bbox.x, bbox.y, 920, 500, 20);

			//Text of the recognized speech. Position based of of bounding box values
			noStroke();
			fill(0);
			textFont(font);
			textSize(32);
			text(speechRec.resultString, bbox.x*1.2, bbox.y*1.3, 910, windowHeight);


		}else if(bbox.w > 900){ //settings for shorter paragraphs
			background(51, 153, 255);

			noStroke();
			fill(255);
			triangle(bbox.x+45, bbox.y+10, 200, 0, 260, bbox.y+10);

			//Draws text bubble background based on the positioning of bounding box
			noStroke();
			fill(255);
			rect(bbox.x, bbox.y, 920, bbox.h * 5, 20);

			//Text of the recognized speech. Position based of of bounding box values
			noStroke();
			fill(0);
			textFont(font);
			textSize(32);
			text(speechRec.resultString, bbox.x*1.2, bbox.y*1.3, 910, windowHeight);
		
		}else if(bbox.w > 200){ //settings for short sentences
			background(51, 153, 255);

			noStroke();
			fill(255);
			triangle(bbox.x+45, bbox.y+10, 200, 0, 260, bbox.y+10);

			//Draws text bubble background based on the positioning of bounding box
			noStroke();
			fill(255);
			rect(bbox.x, bbox.y, bbox.w * 1.2, bbox.h * 2, 20);

			//Text of the recognized speech. Position based of of bounding box values
			noStroke();
			fill(0);
			textFont(font);
			textSize(32);
			text(speechRec.resultString, bbox.x*1.1, bbox.y*1.1, 910, windowHeight);

		}else{ //settings for short words
			background(51, 153, 255);
			
			noStroke();
			fill(255);
			triangle(bbox.x+45, bbox.y+10, 200, 0, 260, bbox.y+10);

			//Draws text bubble background based on the positioning of bounding box
			noStroke();
			fill(255);
			rect(bbox.x, bbox.y, 200, bbox.h * 2.5, 20);

			//Text of the recognized speech. Position based of of bounding box values
			noStroke();
			fill(0);
			textFont(font);
			textSize(32);
			text(speechRec.resultString, bbox.x*1.1, bbox.y*1.1, 910, windowHeight);

		}
		
	}
}



